#ifndef _LEDEXTENSIONS_H
#define _LEDEXTENSIONS_H

#include "WProgram.h"

#ifdef __cplusplus
extern "C"{
#endif

void setRGB(uint8_t r, uint8_t g, uint8_t b);

#ifdef __cplusplus
} // extern "C"
#endif


#endif