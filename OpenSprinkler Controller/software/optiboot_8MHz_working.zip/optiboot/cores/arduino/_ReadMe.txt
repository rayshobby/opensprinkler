Arduino does not currently allow additional hardware directories to share the standard Arduino core. So a copy of the Arduino 18 core is included here. No changes have been made.

Arduino source is from http://arduino.cc
