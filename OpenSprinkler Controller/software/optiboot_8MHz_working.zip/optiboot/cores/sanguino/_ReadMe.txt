Arduino does not currently allow additional hardware directories to share the
Sanguino core. So a copy of the Sanguino 18 core is included here. No changes
have been made.

Sanguino source is from http://sanguino.cc
