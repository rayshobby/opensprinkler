#!/usr/bin/python
import ospi

  #### Add any new page urls here ####
ospi.urls.extend([]) # example: (['/c1', 'custom_page_1, '/c2', 'custom_page_2', '/c3', 'custom_page_3'])

##print ospi.urls # for testing

  #### add new functions and classes here ####

  ### Example custom class. Uncomment and use to create a new web page. ###
##class custom_page_1:
##   """Add description here"""
##   def GET(self):
##      custpg = '<!DOCTYPE html>\n'
##      #Insert Custom Code here.
##      return custpg



  
