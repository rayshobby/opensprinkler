#!/usr/bin/python

class gv:
    """An empty class for storing global vars."""
    pass
